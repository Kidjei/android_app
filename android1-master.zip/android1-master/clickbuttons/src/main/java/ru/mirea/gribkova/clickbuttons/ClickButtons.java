package ru.mirea.gribkova.clickbuttons;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ClickButtons extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_click_buttons);
    }
}